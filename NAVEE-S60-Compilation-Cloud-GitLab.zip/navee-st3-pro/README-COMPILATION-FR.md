# NAVEE S60 — compilation APK sans Android Studio

Ce paquet contient le projet Android/Kotlin NAVEE S60 et une configuration GitLab CI
pour compiler automatiquement l'APK debug dans le cloud.

## Compiler l'application

1. Décompresser cette archive.
2. Créer un projet GitLab privé (ou utiliser un projet existant).
3. Envoyer **le contenu du dossier** `navee-st3-pro` dans le dépôt GitLab.
   Le fichier `.gitlab-ci.yml` doit être à la racine du dépôt et le dossier `android`
   doit se trouver juste en dessous.
4. Vérifier que les pipelines CI/CD sont autorisés pour le projet.
5. Ouvrir **Build > Pipelines** dans GitLab et lancer le pipeline (ou pousser un commit).
6. Quand le job `build_debug_apk` est terminé avec succès, ouvrir le job puis télécharger
   son artefact. Le fichier attendu est :
   `android/app/build/outputs/apk/debug/app-debug.apk`

## Important

- Android Studio n'est pas nécessaire.
- La compilation nécessite un runner GitLab avec accès à Internet et l'image Docker
  `mingc/android-build-box:latest`.
- Ce paquet prépare le pipeline ; il ne contient pas un APK nouvellement compilé.
- Si le pipeline échoue, transmettre le journal complet du job pour corriger l'erreur.
- L'APK `debug` est destiné aux tests et n'est pas une version Play Store signée.

## Paramètres du projet repérés

- Application ID : `de.pepperonas.navee`
- SDK compile/target : 35
- SDK minimum : 26
- Gradle Wrapper : 8.11.1
